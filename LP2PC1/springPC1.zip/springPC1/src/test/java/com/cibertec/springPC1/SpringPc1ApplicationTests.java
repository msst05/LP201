package com.cibertec.springPC1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPc1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
